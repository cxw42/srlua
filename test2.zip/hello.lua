print "Hello, world!"
